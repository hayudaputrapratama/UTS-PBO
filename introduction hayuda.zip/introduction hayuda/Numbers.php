<?php\
//hayuda_putra_pratama
//2255201041
//semester_3
// Write your code below:
  $age = 11;
echo $age;
echo "\n";
$movie_rating = 3.2;
echo $movie_rating;
  