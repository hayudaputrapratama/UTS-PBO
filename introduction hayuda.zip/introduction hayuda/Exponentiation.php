<?php
//hayuda_putra_pratama
//2255201041
//semester_3
// Write your code below:
echo 8 **  2;
  