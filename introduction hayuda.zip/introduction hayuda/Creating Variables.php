<?php
//hayuda_putra_pratama
//2255201041
//semester_3
$silly = "without common sense, absurd, ridiculous";
$biography = "\nCodecademy is an education company. But not one in the way you might think. We're committed to building the best learning experience inside and out, making Codecademy the best place for our team to learn, teach, and create the online learning experience of the future.";
$favorite_food = "\n"."tur"."duck"."en";
  
  
  


