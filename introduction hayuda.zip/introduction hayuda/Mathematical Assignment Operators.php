<?php
//hayuda_putra_pratama
//2255201041
//semester_3
// Write your code below:
$savings = 800;
$bike_cost = 75;
$savings = $savings - $bike_cost;
echo $savings; // Prints: 725
  