<?php
//hayuda_putra_pratama
//2255201041
//semester_3
echo "\n"."tur" . "duck" . "en";
