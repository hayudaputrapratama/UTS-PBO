<?php
//hayuda_putra_pratama
//2255201041
//semester_3
  $movie = "dora";
  $old_favorite = $movie;
// Add your code here:



  echo "I'm a fickle person, my favorite movie used to be $movie.";
  
// Add a statement here:
$movie = "naruto sipiubde";  
  
  echo "\nBut now my favorite is $old_favorite.";
  
// Add a statement below:

