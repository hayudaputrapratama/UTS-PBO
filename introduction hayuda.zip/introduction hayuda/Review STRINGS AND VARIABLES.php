<?php
//hayuda_putra_pratama
//2255201041
//semester_3
	echo "Hello, Learner!";

	echo "\nWe hope you enjoyed this lesson.";
    
  echo "\nAre you excited?" . "\nTo learn more?";
    
  $favorite_language = "PHP";

  $message = "$favorite_language is by far our favorite language.";

  $message .= " It's yours now too, right?";
    
  echo "\n" . $message . " Right?!";  

  