<?php
//hayuda_putra_pratama
//2255201041
//semester_3
// Write your code below: 
  echo "1. Teach PHP";
 echo "\n2. Another thing to do";
  echo "\n3. Another \"thing\" to do"; 
 