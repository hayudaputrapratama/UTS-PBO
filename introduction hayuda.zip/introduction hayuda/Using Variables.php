<?php
//hayuda_putra_pratama
//2255201041
//semester_3
$food = "language";
echo "\nI love " . $language;


  