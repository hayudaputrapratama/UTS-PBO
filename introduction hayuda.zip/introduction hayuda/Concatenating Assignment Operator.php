<?php
//hayuda_putra_pratama
//2255201041
//semester_3
  echo "I'm going on a picnic!";

  $sentence = "\nI'm going on a picnic, and I'm taking apples";

$sentence .= ", bobo";
$sentence .=", cicak";
  echo $sentence;


// Write your code below:
