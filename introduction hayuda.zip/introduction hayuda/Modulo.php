<?php
//hayuda_putra_pratama
//2255201041
//semester-3
// Write your code below:
  echo 21 % 8;