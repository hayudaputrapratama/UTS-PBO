<?php
//hayuda_putra_pratama
//2255201041
//semester_3
namespace Codecademy;
$my_array = ["panda" => "very cute", "lizard" => "cute", "cockroach" => "not very cute"];
$favorites = array(
  "person" => "ourself", 
  "age" => 11117, 
  "foods" => ["twigs", "ice-cream", "salt", "cookies"]
// Write your code below:
