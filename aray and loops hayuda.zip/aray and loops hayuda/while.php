            <?php
//hayuda_putra_pratama
//2255201041
//semester_3
$count = 1;
while ($count < 11)
{
  echo "The count is: " . $count . "\n";
  $count += 1;
}
